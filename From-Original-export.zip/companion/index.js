import * as simpleSettings from "./simple/companion-settings";

simpleSettings.initialize();
